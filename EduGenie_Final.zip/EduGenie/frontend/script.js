const API = window.location.origin;

function showPage(id) {
  document.querySelectorAll(".page").forEach((p) => p.classList.remove("active-page"));
  const page = document.getElementById(id);
  if (page) page.classList.add("active-page");

  document.querySelectorAll(".nav").forEach((n) => {
    n.classList.toggle("active", n.dataset.page === id);
  });

  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll(".nav").forEach((button) => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

document.querySelectorAll("[data-go]").forEach((element) => {
  element.addEventListener("click", () => showPage(element.dataset.go));
});

async function post(url, data) {
  const response = await fetch(`${API}${url}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  let payload = {};
  try {
    payload = await response.json();
  } catch (_) {}

  if (!response.ok) {
    throw new Error(payload.detail || `Request failed (${response.status})`);
  }

  return payload;
}

function setBusy(button, busy, normalText) {
  button.disabled = busy;
  button.textContent = busy ? "EduGenie is thinking... ✦" : normalText;
}

function showResult(element, text, type = "") {
  element.classList.remove("hidden", "error", "success");
  if (type) element.classList.add(type);
  element.textContent = text;
}

async function askAI() {
  const input = document.getElementById("question");
  const result = document.getElementById("answer");
  const button = document.getElementById("askButton");
  const question = input.value.trim();

  if (!question) {
    showResult(result, "Please enter a question.", "error");
    return;
  }

  setBusy(button, true, "Ask EduGenie ✦");
  showResult(result, "EduGenie is thinking... ✦");

  try {
    const data = await post("/api/ask", { question });
    showResult(result, data.answer, "success");
  } catch (error) {
    showResult(result, error.message, "error");
  } finally {
    setBusy(button, false, "Ask EduGenie ✦");
  }
}

async function summarize() {
  const input = document.getElementById("summaryText");
  const result = document.getElementById("summaryResult");
  const button = document.getElementById("summaryButton");
  const text = input.value.trim();

  if (!text) {
    showResult(result, "Please paste some educational text.", "error");
    return;
  }

  setBusy(button, true, "Summarize ✦");
  showResult(result, "Creating your summary... ✦");

  try {
    const data = await post("/api/summarize", { text });
    showResult(result, data.summary, "success");
  } catch (error) {
    showResult(result, error.message, "error");
  } finally {
    setBusy(button, false, "Summarize ✦");
  }
}

async function makePath() {
  const topic = document.getElementById("pathTopic").value.trim();
  const level = document.getElementById("pathLevel").value;
  const result = document.getElementById("pathResult");
  const button = document.getElementById("pathButton");

  if (!topic) {
    showResult(result, "Please enter a topic.", "error");
    return;
  }

  setBusy(button, true, "Create My Learning Path ✦");
  showResult(result, "Building your learning path... ✦");

  try {
    const data = await post("/api/learning-path", { topic, level });
    showResult(result, data.path, "success");
  } catch (error) {
    showResult(result, error.message, "error");
  } finally {
    setBusy(button, false, "Create My Learning Path ✦");
  }
}

async function generateQuiz() {
  const area = document.getElementById("quizArea");
  const button = document.getElementById("quizButton");
  const topic = document.getElementById("quizTopic").value.trim();
  const count = Number(document.getElementById("quizCount").value);

  if (!topic) {
    area.className = "result error";
    area.textContent = "Please enter a quiz topic.";
    return;
  }

  area.className = "result";
  area.textContent = "Creating your quiz... ✦";
  setBusy(button, true, "Generate Quiz ✦");

  try {
    const data = await post("/api/quiz", { topic, count });
    renderQuiz(data.questions);
  } catch (error) {
    area.className = "result error";
    area.textContent = error.message;
  } finally {
    setBusy(button, false, "Generate Quiz ✦");
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (match) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[match]));
}

function renderQuiz(questions) {
  const area = document.getElementById("quizArea");
  area.className = "";
  area.innerHTML = "";

  questions.forEach((question, index) => {
    const card = document.createElement("div");
    card.className = "quiz-card";

    const options = question.options.map((option, optionIndex) =>
      `<label class="option">
        <input type="radio" name="q${index}" value="${optionIndex}">
        ${escapeHtml(option)}
      </label>`
    ).join("");

    card.innerHTML = `
      <h3>${index + 1}. ${escapeHtml(question.question)}</h3>
      ${options}
      <div id="exp${index}" class="hidden result"></div>
    `;

    area.appendChild(card);
  });

  const submit = document.createElement("button");
  submit.className = "primary";
  submit.textContent = "Submit Quiz";
  submit.addEventListener("click", () => scoreQuiz(questions));
  area.appendChild(submit);

  area.scrollIntoView({ behavior: "smooth", block: "start" });
}

function scoreQuiz(questions) {
  let score = 0;

  questions.forEach((question, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    const explanation = document.getElementById(`exp${index}`);
    explanation.classList.remove("hidden");

    if (selected && Number(selected.value) === question.answer) {
      score += 1;
      explanation.className = "result success";
      explanation.textContent = `✓ Correct! ${question.explanation}`;
    } else {
      explanation.className = "result error";
      explanation.textContent = `✗ Review this question. ${question.explanation}`;
    }
  });

  const oldScore = document.querySelector(".score");
  if (oldScore) oldScore.remove();

  const scoreBox = document.createElement("div");
  scoreBox.className = "score";
  scoreBox.innerHTML = `<b>${score}/${questions.length}</b><br><br>You completed the quiz!`;
  document.getElementById("quizArea").prepend(scoreBox);
  scoreBox.scrollIntoView({ behavior: "smooth", block: "start" });
}

document.getElementById("askButton").addEventListener("click", askAI);
document.getElementById("summaryButton").addEventListener("click", summarize);
document.getElementById("pathButton").addEventListener("click", makePath);
document.getElementById("quizButton").addEventListener("click", generateQuiz);

document.getElementById("question").addEventListener("keydown", (event) => {
  if (event.ctrlKey && event.key === "Enter") askAI();
});
